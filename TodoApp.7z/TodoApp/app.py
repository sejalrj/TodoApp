''' 1.flask.request -> request.form['data'] -- form data parameters
    flask_restful.request -> request.args.get('data') --> query parameters/ could be sent from browser ?data=some_string
    2.you can return any iterable and it will be converted into a response, including raw Flask response objects.
'''

from flask import Flask
from flask_restful import Resource,Api, request

app = Flask(__name__)
api = Api(app)

tasks = {'todo1': "Do it now"}


class TodoApi(Resource):
    def get(self, task_id):
        return {"task_id" : tasks[task_id]}

    def post(self, task_id):
        tasks[task_id] = request.args.get("data")
        return [{"task_id": tasks[task_id]}]


api.add_resource(TodoApi, '/<string:task_id>')


if __name__ == '__main__':
    app.run(debug=True)
